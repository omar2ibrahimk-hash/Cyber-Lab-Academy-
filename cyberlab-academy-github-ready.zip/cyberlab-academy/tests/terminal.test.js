const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
process.env.CYBERLAB_WORKSPACES = fs.mkdtempSync(path.join(os.tmpdir(), 'cyberlab-terminal-tests-'));
const { tokenize, ALLOWED, runLabCommand } = require('../backend/terminal');

test('terminal tokenizes simple commands and quoted text', () => {
  assert.deepEqual(tokenize('ls'), ['ls']);
  assert.deepEqual(tokenize('echo "hello world"'), ['echo', 'hello world']);
  assert.deepEqual(tokenize("cat 'practice.txt'"), ['cat', 'practice.txt']);
});

test('terminal rejects shell chaining and substitutions', () => {
  for (const command of ['ls; cat /etc/passwd', 'cat file | grep x', 'echo $HOME', 'touch x && date', 'cat `whoami`']) {
    assert.throws(() => tokenize(command));
  }
});

test('terminal command allowlist excludes destructive and network tools', () => {
  assert.ok(ALLOWED.has('ls'));
  assert.ok(ALLOWED.has('grep'));
  assert.equal(ALLOWED.has('rm'), false);
  assert.equal(ALLOWED.has('nmap'), false);
  assert.equal(ALLOWED.has('curl'), false);
  assert.equal(ALLOWED.has('sudo'), false);
});

test('real Linux commands run inside a per-user workspace', async () => {
  assert.equal(await runLabCommand(987654, 'pwd'), '/home/learner');
  const listing = await runLabCommand(987654, 'ls');
  assert.match(listing, /practice\.txt/);
  assert.match(await runLabCommand(987654, 'grep Welcome practice.txt'), /Welcome/);
  assert.match(await runLabCommand(987654, 'date'), /\d{4}/);
  await runLabCommand(987654, 'touch test-file.txt');
  assert.match(await runLabCommand(987654, 'ls'), /test-file\.txt/);
  await assert.rejects(() => runLabCommand(987654, 'cat ../../../../etc/passwd'));
  await assert.rejects(() => runLabCommand(987654, 'ls; cat /etc/passwd'));
});
