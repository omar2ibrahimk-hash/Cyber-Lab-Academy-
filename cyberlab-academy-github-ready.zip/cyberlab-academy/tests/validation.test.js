const test = require('node:test');
const assert = require('node:assert/strict');
const { validateRegistration } = require('../backend/validation');

test('registration rejects short password and malformed username', () => {
  const result = validateRegistration({username:'x!',email:'not-an-email',password:'short',ageRange:'13-15',educationLevel:'classes6-8',skillLevel:'beginner'});
  assert.ok(result.errors.length >= 3);
});

test('registration accepts valid shape without exposing extra fields', () => {
  const result = validateRegistration({username:'learner_12',email:'Learner@example.com',password:'long-enough-password',ageRange:'13-15',educationLevel:'classes6-8',skillLevel:'beginner',acceptTerms:true,acceptPrivacy:true,acceptRules:true,admin:true});
  assert.equal(result.errors.length, 0);
  assert.equal(result.value.email, 'learner@example.com');
  assert.equal('admin' in result.value, false);
});

test('registration requires explicit policy and responsible-use acknowledgements', () => {
  const result = validateRegistration({username:'learner_12',email:'learner@example.com',password:'long-enough-password',ageRange:'13-15',educationLevel:'classes6-8',skillLevel:'beginner'});
  assert.ok(result.errors.some(error => error.includes('Terms & Conditions')));
  assert.ok(result.errors.some(error => error.includes('Privacy Policy')));
  assert.ok(result.errors.some(error => error.includes('authorized environments')));
});

test('privacy and terms pages are present and explain the safe-use boundary', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const privacy = fs.readFileSync(path.join(__dirname, '..', 'public', 'privacy.html'), 'utf8');
  const terms = fs.readFileSync(path.join(__dirname, '..', 'public', 'terms.html'), 'utf8');
  assert.match(privacy, /Privacy Policy/);
  assert.match(privacy, /account deletion/i);
  assert.match(terms, /Terms &amp; Conditions/);
  assert.match(terms, /explicit permission/i);
});

test('registration normalizes usernames to avoid case-variant duplicates', () => {
  const { value } = validateRegistration({
    username: 'CyberLearner',
    email: 'Learner@example.com',
    password: 'this-is-a-long-password',
    ageRange: '13-15',
    educationLevel: 'classes6-8',
    skillLevel: 'beginner',
    acceptTerms: true,
    acceptPrivacy: true,
    acceptRules: true
  });
  assert.equal(value.username, 'cyberlearner');
  assert.equal(value.email, 'learner@example.com');
});
