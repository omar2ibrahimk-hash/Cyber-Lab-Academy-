const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const USERNAME_RE = /^[a-zA-Z0-9_]{3,24}$/;
const ALLOWED_AGES = new Set(['under13', '13-15', '16-17', '18plus']);
const ALLOWED_EDUCATION = new Set(['classes1-5','classes6-8','classes9-10','classes11-12','college','self-taught','advanced']);
const ALLOWED_SKILLS = new Set(['beginner','intermediate','advanced']);

function validateRegistration(body = {}) {
  const errors = [];
  const username = typeof body.username === 'string' ? body.username.trim().toLowerCase() : '';
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  const password = typeof body.password === 'string' ? body.password : '';
  if (!USERNAME_RE.test(username)) errors.push('Username must be 3–24 letters, numbers, or underscores.');
  if (email.length > 254 || !EMAIL_RE.test(email)) errors.push('Enter a valid email address.');
  if (password.length < 10 || password.length > 72) errors.push('Password must be 10–72 characters.');
  if (!ALLOWED_AGES.has(body.ageRange)) errors.push('Choose an age range.');
  if (!ALLOWED_EDUCATION.has(body.educationLevel)) errors.push('Choose an education level.');
  if (!ALLOWED_SKILLS.has(body.skillLevel)) errors.push('Choose a skill level.');
  if (body.acceptTerms !== true) errors.push('You must agree to the Terms & Conditions.');
  if (body.acceptPrivacy !== true) errors.push('You must acknowledge the Privacy Policy.');
  if (body.acceptRules !== true) errors.push('You must agree to practise only in authorized environments.');
  return { errors, value: { username, email, password, ageRange: body.ageRange, educationLevel: body.educationLevel, skillLevel: body.skillLevel, acceptTerms: body.acceptTerms, acceptPrivacy: body.acceptPrivacy, acceptRules: body.acceptRules } };
}

module.exports = { validateRegistration };
