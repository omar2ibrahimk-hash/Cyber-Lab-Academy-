require('dotenv').config();
const fs = require('node:fs/promises');
const path = require('node:path');
const { pool } = require('./db');

(async () => {
  try {
    const schema = await fs.readFile(path.join(__dirname, '..', 'database', 'schema.sql'), 'utf8');
    const seed = await fs.readFile(path.join(__dirname, '..', 'database', 'seed.sql'), 'utf8');
    await pool.query(schema);
    await pool.query(seed);
    console.log('Database schema initialized and starter courses seeded.');
  } catch (err) {
    console.error('Database initialization failed:', err.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
