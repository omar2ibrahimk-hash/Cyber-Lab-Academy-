require('dotenv').config();
const express = require('express');
const session = require('express-session');
const connectPgSimple = require('connect-pg-simple');
const bcrypt = require('bcrypt');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('node:path');
const { pool } = require('./db');
const { validateRegistration } = require('./validation');
const { runLabCommand, removeLabWorkspace } = require('./terminal');

const app = express();
const PgSession = connectPgSimple(session);
const isProduction = process.env.NODE_ENV === 'production';

// Refuse to start with an unsafe session configuration instead of failing later.
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error('SESSION_SECRET must be set to at least 32 characters in .env.');
}

if (process.env.TRUST_PROXY === 'true') app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: isProduction ? [] : null
    }
  }
}));
app.use(express.json({ limit: '20kb' }));
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use(session({
  store: new PgSession({ pool, tableName: 'session', createTableIfMissing: false }),
  name: 'cyberlab.sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: 'lax',
    maxAge: 1000 * 60 * 60 * 8
  }
}));
app.use(express.static(path.join(__dirname, '..', 'public'), { index: 'index.html', maxAge: isProduction ? '1h' : 0 }));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many attempts. Please wait and try again.' } });
const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false });
const terminalLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Terminal rate limit reached. Wait a minute and try again.' } });
app.use('/api', apiLimiter);

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Please log in to continue.' });
  next();
}
function publicUser(row) {
  return { id: row.id, username: row.username, email: row.email, ageRange: row.age_range, educationLevel: row.education_level, skillLevel: row.skill_level };
}
function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

app.get('/api/health', asyncRoute(async (_req, res) => {
  await pool.query('SELECT 1');
  res.json({ status: 'ok', database: 'connected' });
}));

app.post('/api/auth/register', authLimiter, asyncRoute(async (req, res) => {
  const { errors, value } = validateRegistration(req.body);
  if (errors.length) return res.status(400).json({ error: errors[0], errors });
  const passwordHash = await bcrypt.hash(value.password, 12);
  try {
    const result = await pool.query(
      `INSERT INTO users (username,email,password_hash,age_range,education_level,skill_level,accepted_terms_at,accepted_privacy_at)
       VALUES ($1,$2,$3,$4,$5,$6,NOW(),NOW())
       RETURNING id,username,email,age_range,education_level,skill_level`,
      [value.username, value.email, passwordHash, value.ageRange, value.educationLevel, value.skillLevel]
    );
    req.session.regenerate((err) => {
      if (err) return res.status(500).json({ error: 'Could not create a secure session.' });
      req.session.userId = result.rows[0].id;
      req.session.save((saveErr) => {
        if (saveErr) return res.status(500).json({ error: 'Account created, but sign-in could not be completed.' });
        res.status(201).json({ user: publicUser(result.rows[0]) });
      });
    });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'That username or email is already registered.' });
    throw err;
  }
}));

app.post('/api/auth/login', authLimiter, asyncRoute(async (req, res) => {
  const identity = typeof req.body.identity === 'string' ? req.body.identity.trim().toLowerCase() : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!identity || !password || identity.length > 254 || password.length > 72) return res.status(400).json({ error: 'Enter your username/email and password.' });
  const result = await pool.query(
    `SELECT id,username,email,password_hash,age_range,education_level,skill_level
     FROM users WHERE LOWER(username)=LOWER($1) OR email=$1 LIMIT 1`,
    [identity]
  );
  const row = result.rows[0];
  const valid = row ? await bcrypt.compare(password, row.password_hash) : false;
  if (!valid) return res.status(401).json({ error: 'Incorrect username/email or password.' });
  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: 'Could not create a secure session.' });
    req.session.userId = row.id;
    req.session.save((saveErr) => {
      if (saveErr) return res.status(500).json({ error: 'Could not save your session.' });
      res.json({ user: publicUser(row) });
    });
  });
}));

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ error: 'Could not log out.' });
    res.clearCookie('cyberlab.sid', { httpOnly: true, sameSite: 'lax', secure: isProduction });
    res.json({ ok: true });
  });
});

app.get('/api/me', requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query('SELECT id,username,email,age_range,education_level,skill_level FROM users WHERE id=$1', [req.session.userId]);
  if (!result.rowCount) return res.status(401).json({ error: 'Account not found.' });
  res.json({ user: publicUser(result.rows[0]) });
}));

app.patch('/api/me', requireAuth, asyncRoute(async (req, res) => {
  const { ageRange, educationLevel, skillLevel } = req.body || {};
  const valid = ['under13','13-15','16-17','18plus'].includes(ageRange)
    && ['classes1-5','classes6-8','classes9-10','classes11-12','college','self-taught','advanced'].includes(educationLevel)
    && ['beginner','intermediate','advanced'].includes(skillLevel);
  if (!valid) return res.status(400).json({ error: 'Choose valid age, education, and skill levels.' });
  const result = await pool.query(
    'UPDATE users SET age_range=$1,education_level=$2,skill_level=$3 WHERE id=$4 RETURNING id,username,email,age_range,education_level,skill_level',
    [ageRange, educationLevel, skillLevel, req.session.userId]
  );
  res.json({ user: publicUser(result.rows[0]) });
}));

app.get('/api/courses', asyncRoute(async (_req, res) => {
  const result = await pool.query(`
    SELECT c.id,c.slug,c.title,c.summary,c.level,c.estimated_minutes,
      COUNT(l.id)::int AS lesson_count
    FROM courses c LEFT JOIN lessons l ON l.course_id=c.id
    GROUP BY c.id ORDER BY c.sort_order`);
  res.json({ courses: result.rows });
}));

app.get('/api/courses/:slug', asyncRoute(async (req, res) => {
  const result = await pool.query(`
    SELECT c.id,c.slug,c.title,c.summary,c.level,c.estimated_minutes,
      l.id AS lesson_id,l.slug AS lesson_slug,l.title AS lesson_title,
      l.learning_outcome,l.content_md,l.sort_order
    FROM courses c LEFT JOIN lessons l ON l.course_id=c.id
    WHERE c.slug=$1 ORDER BY l.sort_order`, [req.params.slug]);
  if (!result.rowCount) return res.status(404).json({ error: 'Course not found.' });
  const first = result.rows[0];
  res.json({ course: {
    id:first.id,slug:first.slug,title:first.title,summary:first.summary,level:first.level,estimated_minutes:first.estimated_minutes,
    lessons:result.rows.filter(r=>r.lesson_id).map(r=>({id:r.lesson_id,slug:r.lesson_slug,title:r.lesson_title,learning_outcome:r.learning_outcome,content_md:r.content_md,sort_order:r.sort_order}))
  }});
}));

app.get('/api/lessons/:id/quiz', asyncRoute(async (req, res) => {
  const lessonId = Number(req.params.id);
  if (!Number.isSafeInteger(lessonId) || lessonId < 1) return res.status(400).json({ error: 'Invalid lesson.' });
  const result = await pool.query('SELECT id,question,options FROM quiz_questions WHERE lesson_id=$1 ORDER BY id', [lessonId]);
  res.json({ questions: result.rows });
}));

app.post('/api/lessons/:id/quiz/submit', requireAuth, asyncRoute(async (req, res) => {
  const lessonId = Number(req.params.id);
  const answers = req.body.answers;
  if (!Number.isSafeInteger(lessonId) || lessonId < 1 || !Array.isArray(answers) || answers.length > 30) return res.status(400).json({ error: 'Invalid quiz submission.' });
  const result = await pool.query('SELECT id,question,options,correct_index,explanation FROM quiz_questions WHERE lesson_id=$1 ORDER BY id', [lessonId]);
  if (!result.rowCount || answers.length !== result.rowCount) return res.status(400).json({ error: 'Answer every question before submitting.' });
  let correct = 0;
  const review = result.rows.map((q, i) => {
    const isCorrect = Number.isInteger(answers[i]) && answers[i] === q.correct_index;
    if (isCorrect) correct++;
    return { question: q.question, correct: isCorrect, correctIndex: q.correct_index, explanation: q.explanation };
  });
  const score = Math.round(correct / result.rowCount * 100);
  await pool.query('INSERT INTO quiz_attempts (user_id,lesson_id,score,total_questions) VALUES ($1,$2,$3,$4)', [req.session.userId, lessonId, score, result.rowCount]);
  res.json({ score, correct, total: result.rowCount, passed: score >= 70, review });
}));

app.post('/api/lessons/:id/complete', requireAuth, asyncRoute(async (req, res) => {
  const lessonId = Number(req.params.id);
  if (!Number.isSafeInteger(lessonId) || lessonId < 1) return res.status(400).json({ error: 'Invalid lesson.' });
  const exists = await pool.query('SELECT id FROM lessons WHERE id=$1', [lessonId]);
  if (!exists.rowCount) return res.status(404).json({ error: 'Lesson not found.' });
  await pool.query('INSERT INTO lesson_progress (user_id,lesson_id) VALUES ($1,$2) ON CONFLICT (user_id,lesson_id) DO UPDATE SET completed_at=NOW()', [req.session.userId, lessonId]);
  res.json({ ok: true });
}));

app.get('/api/progress', requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query(`
    SELECT l.id AS lesson_id,l.title AS lesson_title,c.title AS course_title,c.slug AS course_slug,
      p.completed_at, b.lesson_id IS NOT NULL AS bookmarked
    FROM lessons l JOIN courses c ON c.id=l.course_id
    LEFT JOIN lesson_progress p ON p.lesson_id=l.id AND p.user_id=$1
    LEFT JOIN bookmarks b ON b.lesson_id=l.id AND b.user_id=$1
    ORDER BY c.sort_order,l.sort_order`, [req.session.userId]);
  const stats = await pool.query('SELECT COUNT(*)::int AS completed FROM lesson_progress WHERE user_id=$1', [req.session.userId]);
  res.json({ lessons: result.rows, completed: stats.rows[0].completed });
}));

app.get('/api/lab-progress', requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query('SELECT lab_slug, completed_at FROM lab_completions WHERE user_id=$1 ORDER BY completed_at DESC', [req.session.userId]);
  res.json({ labs: result.rows });
}));

app.post('/api/labs/linux-terminal/command', requireAuth, terminalLimiter, asyncRoute(async (req, res) => {
  if (typeof req.body?.command !== 'string' || req.body.command.length > 300) {
    return res.status(400).json({ error: 'Enter a command under 300 characters.' });
  }
  try {
    const output = await runLabCommand(Number(req.session.userId), req.body.command);
    res.json({ ok: true, output });
  } catch (err) {
    const clientError = /^(Enter a command|Shell operators|Unclosed quotation|Type help|Command not available|Usage:|Use a relative|Path must stay|Symbolic links|Folder not found|File not found|Use a simple|Invalid learner|Learner workspace|Workspace storage|Real terminal labs|Run one command)/i.test(err.message || '');
    res.status(clientError || err.code === 'EEXIST' || err.code === 'ENOENT' ? 400 : 500)
      .json({ error: clientError || err.code === 'EEXIST' || err.code === 'ENOENT' ? err.message : 'The lab command could not be completed.' });
  }
}));

app.post('/api/labs/:slug/complete', requireAuth, asyncRoute(async (req, res) => {
  const allowedLabs = new Set(['linux-terminal']);
  if (!allowedLabs.has(req.params.slug)) return res.status(404).json({ error: 'Practice lab not found.' });
  const result = await pool.query(
    `INSERT INTO lab_completions (user_id, lab_slug) VALUES ($1,$2)
     ON CONFLICT (user_id, lab_slug) DO UPDATE SET completed_at=NOW()
     RETURNING lab_slug, completed_at`, [req.session.userId, req.params.slug]);
  res.json({ ok: true, lab: result.rows[0] });
}));

app.get('/api/quiz-attempts', requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query(`
    SELECT q.id, l.title AS lesson_title, c.title AS course_title, q.score,
      q.total_questions, q.created_at
    FROM quiz_attempts q
    JOIN lessons l ON l.id=q.lesson_id
    JOIN courses c ON c.id=l.course_id
    WHERE q.user_id=$1 ORDER BY q.created_at DESC LIMIT 50`, [req.session.userId]);
  res.json({ attempts: result.rows });
}));

app.post('/api/lessons/:id/bookmark', requireAuth, asyncRoute(async (req, res) => {
  const lessonId = Number(req.params.id);
  if (!Number.isSafeInteger(lessonId) || lessonId < 1) return res.status(400).json({ error: 'Invalid lesson.' });
  const exists = await pool.query('SELECT id FROM lessons WHERE id=$1', [lessonId]);
  if (!exists.rowCount) return res.status(404).json({ error: 'Lesson not found.' });
  const current = await pool.query('SELECT 1 FROM bookmarks WHERE user_id=$1 AND lesson_id=$2', [req.session.userId, lessonId]);
  if (current.rowCount) await pool.query('DELETE FROM bookmarks WHERE user_id=$1 AND lesson_id=$2', [req.session.userId, lessonId]);
  else await pool.query('INSERT INTO bookmarks (user_id,lesson_id) VALUES ($1,$2)', [req.session.userId, lessonId]);
  res.json({ bookmarked: !current.rowCount });
}));

app.get('/api/me/export', requireAuth, asyncRoute(async (req, res) => {
  const user = await pool.query('SELECT username,email,age_range,education_level,skill_level,created_at,accepted_terms_at,accepted_privacy_at FROM users WHERE id=$1', [req.session.userId]);
  if (!user.rowCount) return res.status(404).json({ error: 'Account not found.' });
  const [progress, attempts, bookmarks, labs] = await Promise.all([
    pool.query('SELECT l.title AS lesson,c.title AS course,p.completed_at FROM lesson_progress p JOIN lessons l ON l.id=p.lesson_id JOIN courses c ON c.id=l.course_id WHERE p.user_id=$1 ORDER BY p.completed_at', [req.session.userId]),
    pool.query('SELECT l.title AS lesson,score,total_questions,created_at FROM quiz_attempts q JOIN lessons l ON l.id=q.lesson_id WHERE q.user_id=$1 ORDER BY q.created_at', [req.session.userId]),
    pool.query('SELECT l.title AS lesson,c.title AS course,b.created_at FROM bookmarks b JOIN lessons l ON l.id=b.lesson_id JOIN courses c ON c.id=l.course_id WHERE b.user_id=$1 ORDER BY b.created_at', [req.session.userId]),
    pool.query('SELECT lab_slug,completed_at FROM lab_completions WHERE user_id=$1 ORDER BY completed_at', [req.session.userId])
  ]);
  res.setHeader('Content-Disposition', 'attachment; filename="cyberlab-account-data.json"');
  res.json({ exportedAt: new Date().toISOString(), account: user.rows[0], completedLessons: progress.rows, quizAttempts: attempts.rows, bookmarks: bookmarks.rows, completedLabs: labs.rows });
}));

app.delete('/api/me', requireAuth, asyncRoute(async (req, res) => {
  if (req.body?.confirm !== 'DELETE_MY_ACCOUNT') return res.status(400).json({ error: 'Account deletion confirmation is required.' });
  await removeLabWorkspace(Number(req.session.userId));
  await pool.query('DELETE FROM users WHERE id=$1', [req.session.userId]);
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ error: 'Account deleted, but the session could not be cleared. Close your browser.' });
    res.clearCookie('cyberlab.sid', { httpOnly: true, sameSite: 'lax', secure: isProduction });
    res.json({ ok: true });
  });
}));

app.use('/api', (_req, res) => res.status(404).json({ error: 'API route not found.' }));
app.use((err, _req, res, _next) => {
  console.error(err.stack || err.message);
  if (res.headersSent) return;
  res.status(500).json({ error: 'An unexpected server error occurred.' });
});

const port = Number(process.env.PORT) || 3000;
const server = app.listen(port, () => console.log(`CyberLab Academy listening on http://localhost:${port}`));

async function shutdown(signal) {
  console.log(`${signal} received; shutting down gracefully.`);
  server.close(async () => {
    try { await pool.end(); process.exit(0); }
    catch (error) { console.error('Shutdown error:', error.message); process.exit(1); }
  });
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
