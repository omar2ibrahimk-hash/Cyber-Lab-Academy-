'use strict';
const { execFile } = require('node:child_process');
const fs = require('node:fs/promises');
const path = require('node:path');
const { promisify } = require('node:util');
const execFileAsync = promisify(execFile);

const WORKSPACE_ROOT = path.resolve(process.env.CYBERLAB_WORKSPACES || path.join(__dirname, '..', 'data', 'lab-workspaces'));
const MAX_OUTPUT = 12000;
const TIMEOUT_MS = 2000;
const BLOCKED_SHELL_CHARS = /[;|&<>`$\\\n\r]/;
const ALLOWED = new Set(['help', 'pwd', 'ls', 'cat', 'echo', 'date', 'mkdir', 'touch', 'grep', 'clear']);

function tokenize(input) {
  if (typeof input !== 'string' || input.length > 300) throw new Error('Enter a command under 300 characters.');
  if (BLOCKED_SHELL_CHARS.test(input)) throw new Error('Shell operators, substitutions, and command chaining are disabled. Run one command at a time.');
  const args = [];
  let current = '', quote = null, active = false;
  for (const ch of input.trim()) {
    if (quote) {
      if (ch === quote) quote = null;
      else current += ch;
      active = true;
    } else if (ch === '"' || ch === "'") {
      quote = ch; active = true;
    } else if (/\s/.test(ch)) {
      if (active) { args.push(current); current = ''; active = false; }
    } else {
      current += ch; active = true;
    }
  }
  if (quote) throw new Error('Unclosed quotation mark.');
  if (active) args.push(current);
  if (!args.length) throw new Error('Type help to see available commands.');
  return args;
}

function ensureSimpleName(value) {
  if (!value || value.startsWith('-') || path.isAbsolute(value) || value.includes('\0')) throw new Error('Use a relative file or folder name inside your lab workspace.');
  const resolved = path.resolve(this, value);
  if (resolved !== this && !resolved.startsWith(this + path.sep)) throw new Error('Path must stay inside your lab workspace.');
  return resolved;
}

async function assertNoSymlink(root, target) {
  const relative = path.relative(root, target);
  let current = root;
  for (const part of relative.split(path.sep).filter(Boolean)) {
    current = path.join(current, part);
    try {
      const stat = await fs.lstat(current);
      if (stat.isSymbolicLink()) throw new Error('Symbolic links are disabled in this lab.');
    } catch (err) {
      if (err.code === 'ENOENT') break;
      throw err;
    }
  }
}

async function getWorkspace(userId) {
  if (!Number.isSafeInteger(Number(userId)) || Number(userId) < 1) throw new Error('Invalid learner workspace.');
  await fs.mkdir(WORKSPACE_ROOT, { recursive: true, mode: 0o700 });
  const rootStat = await fs.lstat(WORKSPACE_ROOT);
  if (rootStat.isSymbolicLink() || !rootStat.isDirectory()) throw new Error('Workspace storage is not safe.');
  const root = path.join(WORKSPACE_ROOT, String(userId));
  await fs.mkdir(root, { recursive: true, mode: 0o700 });
  const stat = await fs.lstat(root);
  if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error('Learner workspace is not safe.');
  await fs.mkdir(path.join(root, 'notes'), { recursive: true, mode: 0o700 });
  await fs.mkdir(path.join(root, 'sample-logs'), { recursive: true, mode: 0o700 });
  const starter = path.join(root, 'practice.txt');
  try { await fs.writeFile(starter, 'Welcome to CyberLab Academy.\nUse this file to practise safe Linux commands.\n', { flag: 'wx', mode: 0o600 }); }
  catch (err) { if (err.code !== 'EEXIST') throw err; }
  return root;
}

async function removeLabWorkspace(userId) {
  if (!Number.isSafeInteger(Number(userId)) || Number(userId) < 1) throw new Error('Invalid learner workspace.');
  await fs.mkdir(WORKSPACE_ROOT, { recursive: true, mode: 0o700 });
  const rootStat = await fs.lstat(WORKSPACE_ROOT);
  if (rootStat.isSymbolicLink() || !rootStat.isDirectory()) throw new Error('Workspace storage is not safe.');
  const workspace = path.join(WORKSPACE_ROOT, String(userId));
  try {
    const stat = await fs.lstat(workspace);
    if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error('Learner workspace is not safe.');
    await fs.rm(workspace, { recursive: true, force: false, maxRetries: 2 });
  } catch (err) { if (err.code !== 'ENOENT') throw err; }
}

async function runLabCommand(userId, input) {
  const args = tokenize(input);
  const command = args.shift();
  if (!ALLOWED.has(command)) throw new Error(`Command not available: ${command}. Type help.`);
  if (process.platform === 'win32') throw new Error('Real terminal labs currently require a Linux server. The rest of CyberLab Academy can still run on Windows.');
  const cwd = await getWorkspace(userId);
  const run = async (bin, argv = [], runCwd = cwd) => {
    const { stdout, stderr } = await execFileAsync(bin, argv, {
      cwd: runCwd,
      timeout: TIMEOUT_MS,
      maxBuffer: 16 * 1024,
      windowsHide: true,
      shell: false,
      env: { PATH: '/usr/bin:/bin', HOME: cwd, LANG: 'C', LC_ALL: 'C', USER: 'learner', LOGNAME: 'learner' }
    });
    return (stdout || stderr || '').slice(0, MAX_OUTPUT).replaceAll(cwd, '/home/learner').trimEnd();
  };
  const target = async (value) => {
    const resolved = ensureSimpleName.call(cwd, value);
    await assertNoSymlink(cwd, resolved);
    return resolved;
  };
  switch (command) {
    case 'help':
      if (args.length) throw new Error('Usage: help');
      return 'Real Linux commands available in your private workspace: pwd, ls [folder], cat <file>, echo <text>, date, mkdir <folder>, touch <file>, grep <word> <file>, clear. No shell chaining, network tools, or commands outside this workspace.';
    case 'clear':
      if (args.length) throw new Error('Usage: clear');
      return '';
    case 'pwd':
      if (args.length) throw new Error('Usage: pwd');
      return '/home/learner';
    case 'date':
      if (args.length) throw new Error('Usage: date');
      return run('date');
    case 'ls': {
      if (args.length > 1) throw new Error('Usage: ls [folder]');
      const dir = args.length ? await target(args[0]) : cwd;
      const stat = await fs.stat(dir).catch(() => null);
      if (!stat || !stat.isDirectory()) throw new Error('Folder not found in your workspace.');
      return run('ls', ['-la', '--', dir]);
    }
    case 'cat': {
      if (args.length !== 1) throw new Error('Usage: cat <file>');
      const file = await target(args[0]);
      const stat = await fs.stat(file).catch(() => null);
      if (!stat || !stat.isFile() || stat.size > MAX_OUTPUT) throw new Error('File not found or too large (maximum 12 KB).');
      return run('cat', ['--', file]);
    }
    case 'echo':
      if (!args.length) return '';
      return args.join(' ').slice(0, 2000);
    case 'mkdir': {
      if (args.length !== 1) throw new Error('Usage: mkdir <folder>');
      const dir = await target(args[0]);
      await run('mkdir', ['--', dir]);
      return `Created folder ${args[0]}`;
    }
    case 'touch': {
      if (args.length !== 1) throw new Error('Usage: touch <file>');
      const file = await target(args[0]);
      await run('touch', ['--', file]);
      return `Created or updated file ${args[0]}`;
    }
    case 'grep': {
      if (args.length !== 2) throw new Error('Usage: grep <word> <file>');
      if (args[0].length > 80 || args[0].startsWith('-')) throw new Error('Use a simple search word (not a grep option).');
      const file = await target(args[1]);
      const stat = await fs.stat(file).catch(() => null);
      if (!stat || !stat.isFile() || stat.size > MAX_OUTPUT) throw new Error('File not found or too large (maximum 12 KB).');
      return run('grep', ['-n', '--', args[0], file]).catch(err => {
        if (err.code === 1) return 'No matching lines.';
        throw err;
      });
    }
    default: throw new Error('Command not available. Type help.');
  }
}

module.exports = { tokenize, runLabCommand, removeLabWorkspace, ALLOWED };
