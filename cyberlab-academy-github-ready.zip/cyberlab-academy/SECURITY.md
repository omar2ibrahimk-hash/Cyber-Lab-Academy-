# Security Policy

CyberLab Academy is an educational MVP and is not yet a production-ready multi-user cyber range.

## Reporting a vulnerability

Do not post secrets, personal information, or exploit details in public issues. Contact the repository maintainer privately using the contact method listed on the repository profile.

## Deployment warnings

- Never commit `.env`, database credentials, session secrets, user data, or lab workspaces.
- Use HTTPS and a strong random `SESSION_SECRET`.
- Restrict database network access and use a least-privilege database account.
- The restricted Linux command lab runs real programs on the server and is **not** a hardened sandbox. Keep it disabled or private until container/VM isolation and a security review are complete.
- Test only systems you own or have explicit permission to test.
