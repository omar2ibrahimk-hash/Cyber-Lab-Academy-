# CyberLab Academy

A GitHub-ready full-stack cybersecurity learning website built with HTML, CSS, vanilla JavaScript, Node.js, Express, PostgreSQL, and server-side sessions.

## Included in this MVP

- Responsive dark/light educational website
- Age-range, school-class, and experience-level onboarding
- Server-side registration/login/logout, bcrypt password hashing, session cookies, rate limiting, and profile endpoint
- PostgreSQL-backed profile, courses, lessons, quiz attempts, and learning progress
- Three starter courses with written lesson content
- Knowledge-check quizzes with answer explanations
- Real restricted Linux command lab using child processes with shell execution disabled; commands are limited to each learner’s private workspace
- PostgreSQL-backed progress, lesson completion, bookmarks, quiz attempt history, and saved completion for the Linux command lab
- Privacy Policy and Terms & Conditions pages linked in the footer and registration form
- Account data export (JSON) and permanent account deletion from My Progress
- Security headers, server-side validation, parameterized SQL, and basic tests
- SQL schema and seed data

This is a functional MVP, not the entire 12-level platform in the specification. The legal pages are project templates and must be reviewed and completed with the real operator identity/contact and hosting/data-provider details before public launch. Community moderation, email verification/password reset delivery, certificates, admin content editor, and real isolated virtual-machine labs are not implemented yet. Do not describe those features as live until they are built and tested.

## Requirements

- Node.js 20+
- PostgreSQL 14+
- npm

## Run locally

> The website requires a running Node.js server and PostgreSQL database. Uploading these files to GitHub Pages alone will **not** run the backend, database, login, or terminal. Use a Node.js host with PostgreSQL for deployment.

## Setup

1. Create a database, for example:

   ```sql
   CREATE DATABASE cyberlab;
   ```

2. Copy `.env.example` to `.env` and set `DATABASE_URL` and a long random `SESSION_SECRET`.
3. Install packages from the project root:

   ```bash
   npm install
   ```

4. Initialize tables and starter content:

   ```bash
   npm run db:init
   ```

5. Start the website:

   ```bash
   npm start
   ```

6. Open `http://localhost:3000`.

## Legal pages and account controls

- `/privacy.html` explains account data, learning activity, cookies, retention, deletion, and child-safety limitations.
- `/terms.html` explains acceptable use, authorized testing, accounts, educational limitations, and responsible cybersecurity.
- Registration links both pages and records acceptance timestamps.
- My Progress provides a JSON export and account deletion. These controls require the database to be configured and the user to be signed in.
- The legal documents are transparent starter templates, not legal advice. Add a real operator identity and contact email and obtain an appropriate review before public launch.

## Security notes

- Passwords are hashed with bcrypt and never sent back to the browser.
- Sessions are stored in PostgreSQL; cookies are HttpOnly and SameSite=Lax. In production, HTTPS is required for secure cookies.
- Configure `TRUST_PROXY=true` only behind a trusted reverse proxy.
- Set `NODE_ENV=production` in production and use HTTPS.
- Use a managed email service and verified email workflow before enabling account recovery.
- For minors, add a privacy review and appropriate consent process before public deployment. Collect only necessary data.
- The Linux practice lab executes a restricted allowlist of real Linux commands (`pwd`, `ls`, `cat`, `echo`, `date`, `mkdir`, `touch`, and `grep`) using `execFile` with `shell: false`, a short timeout, output limits, and a per-user workspace. Shell operators, arbitrary commands, scripts, and network tools are blocked. Commands execute on the server, not on the learner’s computer. **This is not a secure multi-tenant sandbox.** Do not expose the terminal to the public internet until container/VM isolation, resource limits, filesystem isolation, and a security review have been completed.
- Never test systems without explicit written authorization.

## Put this project on GitHub

1. Download and extract the project ZIP.
2. Create a new empty repository on GitHub.
3. Upload the **contents** of the `cyberlab-academy` folder (including `backend`, `database`, `public`, `tests`, `package.json`, and this README). Do not upload `.env`, `node_modules`, or real learner data.
4. For command-line upload, run these commands from the project folder after installing Git:

   ```bash
   git init
   git add .
   git commit -m "Add CyberLab Academy website"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
   git push -u origin main
   ```

   Replace the example repository URL with your own GitHub repository URL. If the repository already has a remote, use `git remote set-url origin YOUR-REPOSITORY-URL` instead of adding a second remote.

## Tests

```bash
npm test
```

Tests cover registration validation, required policy/safety acknowledgements, legal-page presence, and terminal command parsing/allowlist restrictions. I checked JavaScript syntax and ran the unit tests. A live PostgreSQL-backed browser end-to-end test was not run in this build environment; configure a test PostgreSQL database and complete end-to-end testing before production deployment.

## Project structure

```text
cyberlab-academy/
  backend/
    server.js
    terminal.js
    db.js
    init-db.js
    validation.js
  database/
    schema.sql
    seed.sql
  public/
    index.html
    courses.html
    labs.html
    profile.html
    login.html
    register.html
    css/style.css
    js/main.js
    js/auth.js
    js/courses.js
    js/labs.js
    js/profile.js
  tests/
    validation.test.js
    terminal.test.js
  .env.example
  .gitignore
  package.json
```
