(() => {
  const $ = (s) => document.querySelector(s);
  const output = $('#terminalOutput');
  const form = $('#terminalForm');
  const input = $('#terminalCommand');
  const initial = '<p>Welcome to the CyberLab Linux lab.</p><p>Commands run on the server inside your private lab workspace, not on your own computer.</p><p>Type <strong>help</strong> to begin.</p>';
  function addLine(command, response) {
    const line = document.createElement('p');
    line.className = 'terminal-line';
    const prompt = document.createElement('span');
    prompt.className = 'terminal-prompt';
    prompt.textContent = `learner@cyberlab:~$ ${command}`;
    line.append(prompt);
    output.append(line);
    if (response !== '') {
      const result = document.createElement('pre');
      result.className = 'terminal-result';
      result.textContent = response;
      result.style.whiteSpace = 'pre-wrap';
      result.style.overflowWrap = 'anywhere';
      output.append(result);
    }
    output.scrollTop = output.scrollHeight;
  }
  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const command = input.value.trim();
    if (!command) return;
    input.disabled = true;
    const runButton = form.querySelector('button');
    if (runButton) runButton.disabled = true;
    try {
      const result = await CyberLab.api('/api/labs/linux-terminal/command', {
        method: 'POST', body: JSON.stringify({ command })
      });
      if (command.toLowerCase() === 'clear') output.innerHTML = '';
      else addLine(command, result.output || '');
    } catch (err) {
      addLine(command, err.message.includes('log in')
        ? 'Please log in to use your personal terminal workspace.'
        : err.message);
      if (err.message.includes('log in')) {
        const p = document.createElement('p');
        const a = document.createElement('a'); a.href = '/login.html'; a.textContent = 'Log in';
        p.append(a); output.append(p);
      }
    } finally {
      input.value = '';
      input.disabled = false;
      if (runButton) runButton.disabled = false;
      input.focus();
    }
  });
  $('#resetTerminal')?.addEventListener('click', () => { output.innerHTML = initial; input.value=''; input.focus(); });
  $('#completeLab')?.addEventListener('click', async () => {
    const status = $('#labStatus');
    try {
      await CyberLab.api('/api/labs/linux-terminal/complete', { method: 'POST', body: '{}' });
      status.textContent = 'Completed! This lab is now saved to your account.';
      status.className = 'form-message success';
      $('#completeLab').textContent = '✓ Lab completed';
      CyberLab.toast('Lab completion saved.');
    } catch (err) {
      status.textContent = err.message.includes('log in') ? 'Log in to save this lab completion. Your workspace will be available after signing in.' : err.message;
      status.className = 'form-message error';
      if (err.message.includes('log in')) { const link = document.createElement('a'); link.href = '/login.html'; link.textContent = ' Log in'; status.append(link); }
    }
  });
})();
