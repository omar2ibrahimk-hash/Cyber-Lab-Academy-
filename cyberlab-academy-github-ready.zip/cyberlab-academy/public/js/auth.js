(() => {
  const $ = (s) => document.querySelector(s);
  const message = $('#formMessage');
  const setMessage = (text, error=false) => {
    if (!message) return;
    message.textContent = text;
    message.className = `form-message ${error ? 'error' : 'success'}`;
  };
  const login = $('#loginForm');
  login?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = login.querySelector('button[type="submit"]');
    button.disabled = true;
    setMessage('Signing you in…');
    try {
      const data = await CyberLab.api('/api/auth/login', { method:'POST', body:JSON.stringify({
        identity: $('#identity').value, password: $('#password').value
      })});
      setMessage(`Welcome back, ${data.user.username}.`);
      window.location.href = '/profile.html';
    } catch (err) { setMessage(err.message, true); }
    finally { button.disabled = false; }
  });
  const register = $('#registerForm');
  register?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = register.querySelector('button[type="submit"]');
    button.disabled = true;
    setMessage('Creating your account…');
    try {
      const data = Object.fromEntries(new FormData(register).entries());
      data.ageRange = $('#ageRange').value;
      data.educationLevel = $('#educationLevel').value;
      data.skillLevel = $('#skillLevel').value;
      data.acceptTerms = $('#acceptTerms').checked;
      data.acceptPrivacy = $('#acceptPrivacy').checked;
      data.acceptRules = $('#rules').checked;
      const result = await CyberLab.api('/api/auth/register', { method:'POST', body:JSON.stringify(data) });
      setMessage(`Account created. Welcome, ${result.user.username}.`);
      window.location.href = '/profile.html';
    } catch (err) { setMessage(err.message, true); }
    finally { button.disabled = false; }
  });
})();
