(() => {
  const target = document.querySelector('#courseDetail');
  const slug = new URLSearchParams(location.search).get('slug');
  if (!slug) { target.innerHTML='<div class="empty-state">No course selected. <a href="/courses.html">Browse courses</a>.</div>'; return; }
  const esc = CyberLab.escapeHtml;
  function markdown(text) {
    // Minimal safe renderer for seed content only; escape HTML before formatting.
    let html = esc(text);
    html = html.replace(/^## (.+)$/gm,'<h2>$1</h2>').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/`([^`]+)`/g,'<code>$1</code>');
    html = html.replace(/^(?:- .+(?:\n|$))+?/gm, block => '<ul>'+block.trim().split('\n').map(line=>'<li>'+line.replace(/^- /,'')+'</li>').join('')+'</ul>');
    html = html.split(/\n\n+/).map(p => /^<h2>|^<ul>/.test(p) ? p : '<p>'+p.replace(/\n/g,'<br>')+'</p>').join('');
    return html;
  }
  async function load() {
    try {
      const data = await CyberLab.api('/api/courses/'+encodeURIComponent(slug));
      const c=data.course;
      target.innerHTML=`<div class="eyebrow">${esc(c.level)} COURSE</div><h1>${esc(c.title)}</h1><p class="page-lede">${esc(c.summary)}</p><div class="course-meta course-meta-large"><span>▤ ${c.lessons.length} lessons</span><span>◷ ${c.estimated_minutes} min estimated</span></div><div class="lesson-layout"><aside class="panel lesson-nav"><h3>In this course</h3>${c.lessons.map((l,i)=>`<a href="#lesson-${l.id}"><span>${String(i+1).padStart(2,'0')}</span>${esc(l.title)}</a>`).join('')}</aside><div class="lesson-stack">${c.lessons.map((l,i)=>`<article class="panel lesson-card" id="lesson-${l.id}"><span class="tag">LESSON ${String(i+1).padStart(2,'0')}</span><h2>${esc(l.title)}</h2><p class="outcome"><b>Learning outcome:</b> ${esc(l.learning_outcome)}</p><div class="lesson-content">${markdown(l.content_md)}</div><div class="lesson-actions"><button class="button button-small complete-lesson" data-id="${l.id}">Mark complete</button><button class="button button-small button-outline bookmark-lesson" data-id="${l.id}">☆ Bookmark</button></div><div class="quiz-area" data-quiz="${l.id}"><button class="button button-outline button-small start-quiz" data-id="${l.id}">Take knowledge check</button></div></article>`).join('')}</div></div>`;
      target.querySelectorAll('.complete-lesson').forEach(btn=>btn.addEventListener('click',async()=>{
        try { await CyberLab.api(`/api/lessons/${btn.dataset.id}/complete`,{method:'POST',body:'{}'}); btn.textContent='✓ Completed'; btn.disabled=true; CyberLab.toast('Lesson progress saved.'); }
        catch(e){CyberLab.toast(e.message);}
      }));
      target.querySelectorAll('.bookmark-lesson').forEach(btn=>btn.addEventListener('click',async()=>{
        try { const d=await CyberLab.api(`/api/lessons/${btn.dataset.id}/bookmark`,{method:'POST',body:'{}'}); btn.textContent=d.bookmarked?'★ Bookmarked':'☆ Bookmark'; CyberLab.toast(d.bookmarked?'Lesson bookmarked.':'Bookmark removed.'); }
        catch(e){CyberLab.toast(e.message);}
      }));
      target.querySelectorAll('.start-quiz').forEach(btn=>btn.addEventListener('click',()=>startQuiz(btn.dataset.id)));
    } catch(e) { target.innerHTML=`<div class="empty-state">${esc(e.message)} <a href="/courses.html">Return to courses</a></div>`; }
  }
  async function startQuiz(id) {
    const area=target.querySelector(`[data-quiz="${id}"]`);
    try {
      const data=await CyberLab.api(`/api/lessons/${id}/quiz`);
      if (!data.questions.length) { area.innerHTML='<p>No quiz questions yet.</p>'; return; }
      area.innerHTML=`<h3>Knowledge check</h3><form class="quiz-form">${data.questions.map((q,i)=>`<fieldset><legend>${i+1}. ${esc(q.question)}</legend>${q.options.map((opt,j)=>`<label class="quiz-option"><input type="radio" name="q${i}" value="${j}" required>${esc(opt)}</label>`).join('')}</fieldset>`).join('')}<button class="button button-small" type="submit">Submit answers</button><p class="form-message" aria-live="polite"></p></form>`;
      area.querySelector('form').addEventListener('submit',async e=>{
        e.preventDefault();
        const answers=data.questions.map((q,i)=>Number(new FormData(e.target).get(`q${i}`)));
        const msg=area.querySelector('.form-message');
        try {
          const result=await CyberLab.api(`/api/lessons/${id}/quiz/submit`,{method:'POST',body:JSON.stringify({answers})});
          msg.textContent=`Score: ${result.score}% (${result.correct}/${result.total}). ${result.passed?'Passed!':'Review the lesson and try again.'}`;
          msg.className=`form-message ${result.passed?'success':'error'}`;
          const review=document.createElement('ul'); review.className='quiz-review';
          result.review.forEach(r=>{const li=document.createElement('li');li.textContent=`${r.correct?'Correct':'Review'} — ${r.explanation}`;review.append(li);});
          area.append(review);
        } catch(err) { msg.textContent=err.message; msg.className='form-message error'; }
      });
    } catch(e) { CyberLab.toast(e.message); }
  }
  load();
})();
