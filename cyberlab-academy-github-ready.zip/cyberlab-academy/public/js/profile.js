(() => {
  const $ = (s) => document.querySelector(s);
  const education = {'classes1-5':'Classes 1–5','classes6-8':'Classes 6–8','classes9-10':'Classes 9–10','classes11-12':'Classes 11–12','college':'College','self-taught':'Beginner / self-taught','advanced':'Advanced learner'};
  async function load() {
    try {
      const [me, progress, quizData, labData] = await Promise.all([CyberLab.api('/api/me'), CyberLab.api('/api/progress'), CyberLab.api('/api/quiz-attempts'), CyberLab.api('/api/lab-progress')]);
      const user = me.user;
      $('#welcomeHeading').textContent = `Welcome, ${user.username}.`;
      const done = progress.completed;
      const total = progress.lessons.length;
      const pct = total ? Math.round(done / total * 100) : 0;
      $('#profileContent').innerHTML = `<div class="stats-grid"><article class="stat-card"><span>Lessons completed</span><strong>${done}</strong><small>out of ${total} available</small></article><article class="stat-card"><span>Overall progress</span><strong>${pct}%</strong><div class="progress-track"><span style="width:${pct}%"></span></div></article><article class="stat-card"><span>Learning level</span><strong class="stat-word">${CyberLab.escapeHtml(user.skillLevel)}</strong><small>${CyberLab.escapeHtml(education[user.educationLevel] || user.educationLevel)}</small></article></div><div class="profile-grid"><section class="panel"><div class="panel-heading"><h2>Your lessons</h2><a class="text-link" href="/courses.html">Browse courses →</a></div><div class="progress-list">${progress.lessons.map(l=>`<div class="progress-item"><span class="progress-check ${l.completed_at?'is-done':''}">${l.completed_at?'✓':'·'}</span><div><b>${CyberLab.escapeHtml(l.lesson_title)}</b><small>${CyberLab.escapeHtml(l.course_title)}</small></div><span class="progress-state">${l.completed_at?'Completed':'Not started'}${l.bookmarked?' · ★ Saved':''}</span></div>`).join('')}</div></section><section class="panel"><h2>Learner profile</h2><p class="muted">These settings help tailor lesson recommendations.</p><form id="profileForm"><label for="ageRange">Age range</label><select id="ageRange"><option value="under13">Under 13</option><option value="13-15">13–15</option><option value="16-17">16–17</option><option value="18plus">18 and above</option></select><label for="educationLevel">Class / level</label><select id="educationLevel">${Object.entries(education).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select><label for="skillLevel">Experience</label><select id="skillLevel"><option value="beginner">Beginner</option><option value="intermediate">Intermediate</option><option value="advanced">Advanced</option></select><button class="button button-full" type="submit">Save profile</button><p id="profileMessage" class="form-message" role="status"></p></form></section></div><section class="panel account-tools"><h2>Recent quiz results</h2>${quizData.attempts.length ? `<div class="progress-list">${quizData.attempts.slice(0,10).map(q=>`<div class="progress-item"><div><b>${CyberLab.escapeHtml(q.lesson_title)}</b><small>${CyberLab.escapeHtml(q.course_title)}</small></div><span class="progress-state">${q.score}% · ${q.total_questions} questions</span></div>`).join('')}</div>` : '<p class="muted">Your quiz results will appear here after your first quiz.</p>'}<h2>Practice labs</h2>${labData.labs.length ? `<p>${labData.labs.map(l=>CyberLab.escapeHtml(l.lab_slug.replaceAll('-', ' '))).join(', ')} — completed</p>` : '<p class="muted">No saved practice labs yet.</p>'}<h2>Your data and account</h2><p class="muted">Download a copy of your learning data or permanently delete your account.</p><div class="account-tool-row"><button class="button button-outline" id="exportDataButton" type="button">Download my data (JSON)</button></div><section class="panel danger-zone" style="margin-top:18px"><h3>Delete account</h3><p>This permanently removes your account, saved progress, bookmarks, and quiz history. This cannot be undone.</p><button class="danger-button" id="deleteAccountButton" type="button">Delete my account</button><p id="accountActionMessage" class="form-message" role="status" aria-live="polite"></p></section></section>`;
      $('#ageRange').value = user.ageRange; $('#educationLevel').value = user.educationLevel; $('#skillLevel').value = user.skillLevel;
      $('#profileForm').addEventListener('submit', async e => {
        e.preventDefault();
        const msg = $('#profileMessage');
        try {
          await CyberLab.api('/api/me',{method:'PATCH',body:JSON.stringify({ageRange:$('#ageRange').value,educationLevel:$('#educationLevel').value,skillLevel:$('#skillLevel').value})});
          msg.textContent='Profile updated.'; msg.className='form-message success';
        } catch(err) { msg.textContent=err.message; msg.className='form-message error'; }
      });
      $('#exportDataButton')?.addEventListener('click', async () => {
        const msg = $('#accountActionMessage');
        try {
          const response = await fetch('/api/me/export', { credentials: 'same-origin' });
          if (!response.ok) { const data = await response.json().catch(()=>({})); throw new Error(data.error || 'Could not export your data.'); }
          const blob = await response.blob(); const url = URL.createObjectURL(blob);
          const a = document.createElement('a'); a.href = url; a.download = 'cyberlab-account-data.json'; document.body.append(a); a.click(); a.remove(); URL.revokeObjectURL(url);
          msg.textContent = 'Your data export has been downloaded.'; msg.className = 'form-message success';
        } catch(err) { msg.textContent = err.message; msg.className = 'form-message error'; }
      });
      $('#deleteAccountButton')?.addEventListener('click', async () => {
        const msg = $('#accountActionMessage');
        if (!window.confirm('Delete your account and all saved learning data? This cannot be undone.')) return;
        const confirmation = window.prompt('Type DELETE to confirm permanent account deletion:');
        if (confirmation !== 'DELETE') { msg.textContent = 'Account deletion cancelled.'; msg.className = 'form-message'; return; }
        try {
          await CyberLab.api('/api/me', { method: 'DELETE', body: JSON.stringify({confirm: 'DELETE_MY_ACCOUNT'}) });
          window.location.href = '/?accountDeleted=1';
        } catch(err) { msg.textContent = err.message; msg.className = 'form-message error'; }
      });
    } catch (err) {
      $('#profileContent').innerHTML = `<div class="empty-state"><h2>Log in to see your progress</h2><p>${CyberLab.escapeHtml(err.message)}</p><a class="button" href="/login.html">Log in</a> <a class="button button-outline" href="/register.html">Create account</a></div>`;
    }
  }
  $('#logoutButton')?.addEventListener('click', async () => {
    try { await CyberLab.api('/api/auth/logout',{method:'POST',body:'{}'}); window.location.href='/'; }
    catch(err) { CyberLab.toast(err.message); }
  });
  load();
})();
