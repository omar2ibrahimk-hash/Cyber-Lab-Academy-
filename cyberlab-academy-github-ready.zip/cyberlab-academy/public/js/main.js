(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const toast = (message) => {
    const node = $('#toast');
    if (!node) return;
    node.textContent = message;
    node.classList.add('show');
    window.setTimeout(() => node.classList.remove('show'), 2800);
  };
  window.CyberLab = {
    toast,
    async api(url, options={}) {
      const response = await fetch(url, {
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
        ...options
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Something went wrong.');
      return data;
    },
    escapeHtml(value) {
      return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    }
  };
  const savedTheme = localStorage.getItem('cyberlab-theme');
  if (savedTheme === 'light') document.documentElement.dataset.theme = 'light';
  const themeButton = $('#themeToggle');
  themeButton?.addEventListener('click', () => {
    const light = document.documentElement.dataset.theme !== 'light';
    document.documentElement.dataset.theme = light ? 'light' : 'dark';
    localStorage.setItem('cyberlab-theme', light ? 'light' : 'dark');
  });
  const menu = $('.menu-toggle');
  menu?.addEventListener('click', () => {
    const nav = $('.nav');
    const open = nav.classList.toggle('nav-open');
    menu.setAttribute('aria-expanded', String(open));
  });
  const accountLink = $('#accountLink');
  if (accountLink) {
    fetch('/api/me', { credentials: 'same-origin' }).then(r => r.ok ? r.json() : null).then(data => {
      if (data?.user) {
        accountLink.href = '/profile.html';
        accountLink.textContent = data.user.username;
      }
    }).catch(() => {});
  }
})();
