(() => {
  const $ = (s) => document.querySelector(s);
  let courses = [];
  const icons = ['⌘','◇','⌁','▤','◎','↗'];
  const render = (items, target) => {
    if (!items.length) { target.innerHTML = '<div class="empty-state">No courses match your search. Try another term.</div>'; return; }
    target.innerHTML = items.map((c,i) => `<article class="course-card"><div class="course-card-top"><span class="course-icon icon-${i%4}">${icons[i%icons.length]}</span><span class="tag">${CyberLab.escapeHtml(c.level)}</span></div><h3>${CyberLab.escapeHtml(c.title)}</h3><p>${CyberLab.escapeHtml(c.summary)}</p><div class="course-meta"><span>▤ ${c.lesson_count} lessons</span><span>◷ ${c.estimated_minutes} min</span></div><a class="text-link" href="/course.html?slug=${encodeURIComponent(c.slug)}">View course →</a></article>`).join('');
  };
  async function load() {
    try {
      const data = await CyberLab.api('/api/courses');
      courses = data.courses;
      const featured = $('#featuredCourses');
      if (featured) render(courses.slice(0,3), featured);
      const list = $('#courseList');
      if (list) render(courses, list);
    } catch (err) {
      document.querySelectorAll('#featuredCourses,#courseList').forEach(el => el.innerHTML = `<div class="empty-state">${CyberLab.escapeHtml(err.message)}</div>`);
    }
  }
  function filter() {
    const search = ($('#courseSearch')?.value || '').toLowerCase();
    const level = $('#levelFilter')?.value || 'all';
    render(courses.filter(c => (level === 'all' || c.level === level) && `${c.title} ${c.summary}`.toLowerCase().includes(search)), $('#courseList'));
  }
  $('#courseSearch')?.addEventListener('input', filter);
  $('#levelFilter')?.addEventListener('change', filter);
  load();
})();
