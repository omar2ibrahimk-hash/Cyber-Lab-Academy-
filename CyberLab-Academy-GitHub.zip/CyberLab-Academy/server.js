'use strict';
require('dotenv').config();
const express = require('express');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

const app = express();
const isProduction = process.env.NODE_ENV === 'production';
const port = Number(process.env.PORT || 3000);
if (isProduction && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error('Set SESSION_SECRET to a random value of at least 32 characters in production.');
}
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required. Create a PostgreSQL database and set DATABASE_URL.');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSLMODE === 'disable' ? false : (isProduction ? { rejectUnauthorized: false } : undefined),
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

app.disable('x-powered-by');
app.set('trust proxy', isProduction ? 1 : false);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(session({
  name: 'cyberlab.sid',
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET || 'local-development-only-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, secure: isProduction, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 24 * 7 }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-8', legacyHeaders: false, message: { message: 'Too many attempts. Please wait 15 minutes and try again.' } });
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function initDb() {
  await pool.query(`CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(60) NOT NULL,
    email VARCHAR(254) NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS learning_progress (
    user_id BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    completed_lessons JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
}
function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ message: 'Please sign in first.' });
  next();
}
function publicUser(user) { return { id: String(user.id), name: user.name, email: user.email }; }

app.get('/api/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ status: 'ok', database: 'connected' }); }
  catch (err) { console.error('Health check database error:', err.message); res.status(503).json({ status: 'error', message: 'Database is unavailable.' }); }
});
app.post('/api/auth/register', authLimiter, async (req, res) => {
  const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
  const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (name.length < 2 || name.length > 60) return res.status(400).json({ message: 'Name must be 2–60 characters.' });
  if (email.length > 254 || !emailPattern.test(email)) return res.status(400).json({ message: 'Enter a valid email address.' });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ message: 'Password must be 10–128 characters.' });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query('INSERT INTO users (name,email,password_hash) VALUES ($1,$2,$3) RETURNING id,name,email', [name, email, hash]);
    res.status(201).json({ message: 'Account created. You can now sign in.', user: publicUser(result.rows[0]) });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ message: 'An account with that email already exists.' });
    console.error('Registration error:', err.message); res.status(500).json({ message: 'Could not create the account. Please try again later.' });
  }
});
app.post('/api/auth/login', authLimiter, async (req, res) => {
  const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!emailPattern.test(email) || !password || password.length > 128) return res.status(400).json({ message: 'Enter a valid email and password.' });
  try {
    const result = await pool.query('SELECT id,name,email,password_hash FROM users WHERE email=$1', [email]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ message: 'Email or password is incorrect.' });
    await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
    req.session.user = publicUser(user);
    res.json({ message: 'Signed in successfully.', user: req.session.user });
  } catch (err) { console.error('Login error:', err.message); res.status(500).json({ message: 'Could not sign in right now.' }); }
});
app.post('/api/auth/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ message: 'Could not sign out. Please try again.' });
    res.clearCookie('cyberlab.sid', { httpOnly: true, secure: isProduction, sameSite: 'lax' });
    res.json({ message: 'Signed out successfully.' });
  });
});
app.get('/api/auth/me', (req, res) => res.json({ user: req.session.user || null }));
app.get('/api/progress', requireAuth, async (req, res) => {
  try {
    const result = await pool.query('SELECT completed_lessons FROM learning_progress WHERE user_id=$1', [req.session.user.id]);
    res.json({ completedLessons: result.rows[0]?.completed_lessons || [] });
  } catch (err) { console.error('Progress read error:', err.message); res.status(500).json({ message: 'Could not load progress.' }); }
});
app.put('/api/progress', requireAuth, async (req, res) => {
  const lessons = req.body.completedLessons;
  if (!Array.isArray(lessons) || lessons.length > 500 || lessons.some(x => typeof x !== 'string' || x.length > 100)) return res.status(400).json({ message: 'Progress data is invalid.' });
  const uniqueLessons = [...new Set(lessons)];
  try {
    await pool.query(`INSERT INTO learning_progress (user_id,completed_lessons) VALUES ($1,$2::jsonb)
      ON CONFLICT (user_id) DO UPDATE SET completed_lessons=EXCLUDED.completed_lessons, updated_at=NOW()`, [req.session.user.id, JSON.stringify(uniqueLessons)]);
    res.json({ message: 'Progress saved.', completedLessons: uniqueLessons });
  } catch (err) { console.error('Progress save error:', err.message); res.status(500).json({ message: 'Could not save progress.' }); }
});

const publicDir = path.join(__dirname, 'public');
app.use(express.static(publicDir, { extensions: ['html'] }));
app.get('/{*path}', (req, res, next) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ message: 'API endpoint not found.' });
  res.sendFile(path.join(publicDir, 'index.html'), err => { if (err) next(err); });
});
app.use((err, _req, res, _next) => {
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Request body must be valid JSON.' });
  }
  const status = Number(err && err.status);
  if (status >= 400 && status < 500) {
    return res.status(status).json({ message: 'The request could not be processed.' });
  }
  console.error('Unhandled server error:', err && err.message ? err.message : 'Unknown error');
  return res.status(500).json({ message: 'Unexpected server error.' });
});

initDb().then(() => {
  app.listen(port, () => console.log(`CyberLab Academy listening on port ${port}`));
}).catch(err => {
  console.error('Database initialization failed:', err.message);
  process.exit(1);
});

process.on('SIGTERM', async () => { await pool.end(); process.exit(0); });
