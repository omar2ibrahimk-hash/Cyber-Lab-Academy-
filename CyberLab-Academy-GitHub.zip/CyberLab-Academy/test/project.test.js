'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

test('website includes all core sections and policy pages', () => {
  for (const id of ['home', 'courses', 'labs', 'quiz', 'progress', 'account', 'privacy', 'terms']) {
    assert.match(html, new RegExp(`id="${id}"`), `missing section ${id}`);
  }
});

test('frontend and backend agree on account and progress API routes', () => {
  for (const route of ['/api/health', '/api/auth/register', '/api/auth/login', '/api/auth/logout', '/api/auth/me', '/api/progress']) {
    assert.ok(html.includes(route), `frontend missing ${route}`);
    assert.ok(server.includes(`'${route}'`) || server.includes(`"${route}"`), `backend missing ${route}`);
  }
});

test('website has 24 lessons and a simulated-only terminal', () => {
  assert.match(html, /const TOTAL = 24/);
  assert.match(html, /This terminal is simulated in your browser/);
  assert.match(html, /No OS commands are executed/);
  assert.doesNotMatch(server, /child_process|execSync|spawn\(/);
});

test('server requires database config and hashes passwords', () => {
  assert.match(server, /DATABASE_URL is required/);
  assert.match(server, /bcrypt\.hash\(password, 12\)/);
  assert.match(server, /bcrypt\.compare\(password, user\.password_hash\)/);
  assert.match(server, /req\.session\.regenerate/);
});

test('deployment and package scripts exist', () => {
  assert.ok(fs.existsSync(path.join(root, 'render.yaml')));
  assert.equal(packageJson.scripts.start, 'node server.js');
  assert.equal(packageJson.scripts.test, 'node --test');
});

test('HTML has no duplicate IDs', () => {
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, new Set(ids).size, 'duplicate HTML IDs detected');
});
