# CyberLab Academy

CyberLab Academy is a beginner-friendly cybersecurity education website with six learning paths, 24 lessons, a quiz, a safe simulated terminal, browser progress, and an Express API for student accounts and server-side progress.

## Features

- Responsive single-page website served by Express.
- Six learning paths and 24 beginner/intermediate lessons.
- Interactive quiz and a simulated command console. The console never executes operating-system commands or contacts external systems.
- Student registration and login with bcrypt password hashing and session cookies.
- PostgreSQL tables for users, session storage, and learning progress. Tables are created on startup.
- Authentication rate limiting, Helmet security headers, input validation, and parameterized SQL queries.
- Privacy Policy and Terms sections. These are starter templates, not legal advice. Before a public launch, the site owner must add a real contact method, data-retention details, jurisdiction-specific terms, and an appropriate child-safety/privacy review.
- Render Blueprint starter configuration in `render.yaml`.

## Requirements

- Node.js 20 or newer.
- A PostgreSQL database.
- A long random `SESSION_SECRET` (at least 32 characters in production).

## Run locally

1. Install Node.js and PostgreSQL.
2. Create a database, for example `cyberlab`.
3. Copy `.env.example` to `.env`.
4. Set `DATABASE_URL` and `SESSION_SECRET` in `.env`. For local PostgreSQL only, set `PGSSLMODE=disable` if your setup does not use TLS.
5. Run `npm install`.
6. Run `npm run check` and `npm test`.
7. Run `npm start` and open `http://localhost:3000`.

The health endpoint is `http://localhost:3000/api/health`; it reports healthy only when PostgreSQL can be reached.

## API routes

- `GET /api/health` — database health check.
- `POST /api/auth/register` — JSON `{ "name", "email", "password" }`; password length 10–128 characters.
- `POST /api/auth/login` — JSON `{ "email", "password" }`.
- `POST /api/auth/logout` — destroys the current session.
- `GET /api/auth/me` — returns the signed-in user or `null`.
- `GET /api/progress` — signed-in users only.
- `PUT /api/progress` — signed-in users only; JSON `{ "completedLessons": ["0", "1"] }`.

## Deployment

`render.yaml` is a deployment blueprint, not a live deployment. To deploy, import this repository into a hosting provider that supports Node.js and managed PostgreSQL, then review the generated resources and environment variables. Do not commit `.env` or real credentials. After deploying, test `/api/health`, registration, sign-in, sign-out, and progress persistence before sharing the URL. GitHub Pages alone cannot run this Node.js backend.

## Important limitations

- The app has not been connected to a live database or deployed from this package.
- The terminal is intentionally simulated. Real command execution is not included.
- Automated tests here are lightweight project/regression checks. A full runtime integration test requires installing dependencies and running a real PostgreSQL database.
