'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const html = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(match => match[1]);
if (scripts.length !== 1) throw new Error(`Expected one inline application script, found ${scripts.length}`);
new vm.Script(scripts[0], { filename: 'public/index.html:inline-script' });
console.log('Frontend JavaScript syntax: OK');
